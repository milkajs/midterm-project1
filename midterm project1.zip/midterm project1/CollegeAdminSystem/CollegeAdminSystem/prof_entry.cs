﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CollegeAdminSystem
{
    public partial class prof_entry : Form
    {
        SqlConnection con;
        SqlDataReader reader;
        SqlCommand cmd;
        public prof_entry()
        {
            
            InitializeComponent();
        }
        public void GetProfData(string name, int id )
        {
            string profName=name;
            int profId=id;
        }

        private void prof_entry_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"data source=ABU-TURAB; initial catalog=College-Management; integrated security=true");
            textBox1.Text = employee_register.SetValueForProfName;
            textBox2.Text = employee_register.SetValueForProfEmpID;
            con.Open();
            cmd = new SqlCommand("select * from professor", con);
            reader = cmd.ExecuteReader();
            con.Close();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int session = Convert.ToInt32(textBox3.Text);
                string courseName = comboBox1.Text;
                con.Open();
                cmd.CommandText = "insert into professor values('" + textBox1.Text + "'," + Convert.ToInt32(textBox2.Text) + "," + session + ",'" + courseName + "')";
                reader = cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("Data entered successfully");
            }
            catch(Exception k)
            {
                MessageBox.Show(k.Message);
            }
            Close();
        }
    }
}
