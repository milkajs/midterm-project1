﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace CollegeAdminSystem
{
    public partial class attendance_check : Form
    {
        SqlConnection con;
        SqlDataReader reader;
        SqlCommand cmd;
        public attendance_check()
        {
            InitializeComponent();
        }

        private void attendance_check_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"data source=ABU-TURAB; initial catalog=College-Management; integrated security=true");

        }
    }
}
