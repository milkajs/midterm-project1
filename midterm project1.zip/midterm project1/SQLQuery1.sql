create table Student(
stud_id int identity(100,1) primary key not null,
stud_name varchar(50) not null,
reg_date varchar(50) not null,
stud_age int not null,
stud_add varchar(50) not null,
stud_phone varchar(50) not null,
stud_email varchar(50) not null,
school_avg float(10) not null,
course_type varchar(50) not null)
select * from student
alter table student add course_type int foreign key references course(course_id)
alter table student drop column course_type
alter table student add constraint course_type foreign key (course_type) references course(course_name)

alter table Faculty add constraint faculty_dean foreign key (faculty_dean) references dean(dean_id)
alter table Faculty add faculty_deanID int foreign key references dean(dean_id)
alter table faculty drop column faculty_dean
sp_rename 'faculty.faculty_deanID', 'fk_faculty_deanId', 'column'
select * from faculty

alter table professor add constraint emp_id foreign key (emp_id) references employee(emp_id)
sp_rename 'professor.emp_id', 'fk_emp_id', 'column'
alter table dean add constraint faculty_id foreign key (faculty_id) references faculty(faculty_id)
sp_rename 'dean.faculty_id', 'fk_faculty_id', 'column'
alter table issuedbooks add constraint book_id foreign key (book_id) references library(book_id)
alter table issuedbooks add constraint stud_id foreign key (stud_id) references student(stud_id)

sp_rename 'issuedbooks.book_id', 'fk_book_id', 'column'
sp_rename 'issuedbooks.stud_id', 'fk_stud_id', 'column'
alter table attendance add constraint prof_id foreign key (prof_id) references professor(prof_id)
alter table attendance drop column stud_id
sp_rename 'attendance.prof_id', 'fk_prof_id', 'column'

alter table attendance add fk_stud_id int foreign key references student(stud_id)
alter table attendance drop column course_name
alter table attendance add  fk_course_id int foreign key references course(course_id)

alter table course add constraint prof_id foreign key (prof_id) references professor(prof_id)

alter table course drop column prof_id
alter table course add fk_prof_id int foreign key references professor(prof_id)
sp_rename 'course.faculty_id', 'fk_faculty_id', 'column'
alter table course add constraint fk_faculty_id foreign key (fk_faculty_id) references faculty(faculty_id)
alter table recordedlecture add constraint prof_id foreign key (prof_id) references professor(prof_id)
alter table recordedlecture drop column prof_id
alter table recordedlecture add fk_prof_id int foreign key references professor(prof_id)
alter table recordedlecture add constraint course_id foreign key (course_id) references course(course_id)
sp_rename 'recordedlecture.course_id','fk_course_id','column'




